<?php
$query_args = array(
    'post_type'      => 'betting',
    'post_status'    => 'publish',
    'posts_per_page' => -1, 
    'order'          => 'ASC',
);

$bet_query = new WP_Query( $query_args );
$items = $bet_query->posts;
?>

<section class="section section-list-loop">
    <div class="list-wrapp">
        <div class="list-items">
            <?php foreach($items as $k => $item) { 
                $k++;
                $post_id = $item->ID;
                $post_title = $item->post_title;
                $url = get_field('offer_url', $post_id);
                $badge = get_field('offer_badge', $post_id);
                $subtitle = get_field('offer_sub_title', $post_id);
                $description = get_field('offer_description', $post_id);
                $score = get_field('rating_score', $post_id);
                $offer_options = get_field('offer_options', $post_id);
                $payment_methods = get_field('payment_methods', $post_id);
                $payment_methods_mob = get_field('payment_methods_mobile', $post_id);
                $button_label = get_field('button_label', $post_id);
                ?>
                <div class="list-item">
                    <div class="badge d-none d-lg-block">
                        <span class="gradient-text"><?= $badge ?></span>
                    </div>
                    <div class="col r-col-1">
                        <span class="number"><?= $k ?></span>

                        <div class="badge d-lg-none">
                            <span class="gradient-text"><?= $badge ?></span>
                        </div>
                    </div>
                    <div class="col r-col-2">
                        <div class="img-wrapp">
                            <a href="<?= $url ? $url : '#' ?>" target="_blank" >
                                <?php echo get_the_post_thumbnail( $post_id); ?>
                            </a>
                        </div>
                    </div>
                    <div class="col r-col-3">
                        <div class="item-description">
                            <div class="title">Bonus de Bienvenue</div>
                            <?= $description ?>
                        </div>
                    </div>
                    <div class="col r-col-4">
                        <?php if ( ! empty( $score ) ) { ?>
                            <div class="d-flex gap-1 flex-md-column align-items-center justify-content-center ">
                                <div class="rating-score"><?= $score ?></div>
                                <div class="stars" style="--rating: <?= $score ?>;" ></div>
                            </div>
                        <?php } ?>
                    </div>

                    <div class="col r-col-5">
                        <a href="<?= $url ?>" class="btn-action" target="_blank">
                            <span>INSCRIVEZ-VOUS</span>
                        </a>
                        <div class="paiment-opt">
                            <img src="<?= $payment_methods_mob['url'] ?>" alt="" width="220px" height="31px">
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</section>