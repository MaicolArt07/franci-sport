<section class="section section-content-block">
    <div class="box-wrapper">
        <?php echo '<InnerBlocks />'; ?>
    </div>
</section>