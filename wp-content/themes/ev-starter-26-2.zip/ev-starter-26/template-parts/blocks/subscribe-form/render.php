<section class="section section-subscribe">
    <div class="row align-items-center">
        <div class="col-md-9">
            <?php echo '<InnerBlocks />'; ?>
        </div>
    </div>  
</section>