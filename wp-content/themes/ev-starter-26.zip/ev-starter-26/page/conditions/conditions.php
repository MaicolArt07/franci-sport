<section class="section section-content-block">
    <div class="box-wrapper border-container-text">

        <p class="fw-bold text-white title-box-wrapper text-uppercase">Conditions d’Utilisation</p>
        <p class="text-white text-box-wrapper">Bienvenue sur placetonbet.fr. En accédant et en utilisant notre site, vous acceptez les présentes conditions générales. Veuillez les lire attentivement</p>

        <p class="fw-bold text-white title-box-wrapper">Information personnelle</p>
        <p class="text-white text-box-wrapper">Nous collectons et stockons certaines informations personnelles afin d'améliorer votre expérience utilisateur. Vos données sont sécurisées et traitées conformément aux réglementations en vigueur.</p>
        
        <p class="fw-bold text-white title-box-wrapper">Utilisation des Informations</p>
        <p class="text-white text-box-wrapper">Vos informations personnelles peuvent être utilisées pour personnaliser votre expérience, vous envoyer des offres pertinentes et améliorer nos services.</p>

        <p class="fw-bold text-white title-box-wrapper">Renseignements automatiquement recueillis et conservés</p>
        <p class="text-white text-box-wrapper">Nous collectons automatiquement certaines données non personnelles, telles que votre adresse IP et vos préférences de navigation, pour analyser et optimiser nos services.</p>
       
        <p class="fw-bold text-white title-box-wrapper">Cookies</p>
        <p class="text-white text-box-wrapper">Les cookies sont utilisés pour améliorer l'expérience utilisateur. Vous pouvez gérer vos préférences via votre navigateur.</p>

        <p class="fw-bold text-white title-box-wrapper">Suppression / Désactivation</p>
        <p class="text-white text-box-wrapper">Vous pouvez demander la suppression ou la désactivation de votre compte et de vos données personnelles en nous contactant.</p>

        <p class="fw-bold text-white title-box-wrapper">Liens vers d’autres sites</p>
        <p class="text-white text-box-wrapper">Notre site peut contenir des liens vers des sites tiers. Nous ne sommes pas responsables de leur contenu ou de leur politique de confidentialité.</p>

        <p class="fw-bold text-white title-box-wrapper">Contenu</p>
        <p class="text-white text-box-wrapper">Tout contenu publié par les utilisateurs doit respecter nos règles. Nous nous réservons le droit de supprimer tout contenu inapproprié.</p>

        <p class="fw-bold text-white title-box-wrapper">Modifications</p>
        <p class="text-white text-box-wrapper">Ces conditions peuvent être mises à jour à tout moment. Nous informerons les utilisateurs des changements importants.</p>

        <p class="fw-bold text-white title-box-wrapper">Contactez-nous</p>
        <p class="text-white text-box-wrapper">Pour toute question, contactez-nous à contact@placetonbet.fr.</p>
    </div>
</section>