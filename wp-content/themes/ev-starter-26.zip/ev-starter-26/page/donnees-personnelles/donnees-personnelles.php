<section class="section section-content-block">
    <div class="box-wrapper border-container-text">

        <p class="fw-bold text-white title-box-wrapper text-uppercase">Données Personnelles</p>
        <p class="text-white text-box-wrapper">Votre confidentialité est essentielle. Cette politique détaille la manière dont nous collectons, utilisons et protégeons vos données.</p>

        <p class="fw-bold text-white title-box-wrapper">Collecte d'Informations</p>
        <p class="text-white text-box-wrapper">Nous collectons des informations personnelles et des données de navigation pour améliorer nos services.</p>
        
        <p class="fw-bold text-white title-box-wrapper">Informations Personnelles</p>
        <p class="text-white text-box-wrapper">Ces données incluent votre nom, email et préférences de jeu.</p>

        <p class="fw-bold text-white title-box-wrapper">Données de Navigation</p>
        <p class="text-white text-box-wrapper">Nous collectons des informations sur votre utilisation du site afin d’optimiser votre expérience.</p>
       
        <p class="fw-bold text-white title-box-wrapper">Utilisation des Données</p>
        <p class="text-white text-box-wrapper">Les données collectées servent à améliorer nos services et proposer des offres adaptées.</p>

        <p class="fw-bold text-white title-box-wrapper">Transfert des Données</p>
        <p class="text-white text-box-wrapper">Nous pouvons partager certaines informations avec des partenaires sous réserve de respect des normes légales.</p>

        <p class="fw-bold text-white title-box-wrapper">Sécurité des Données</p>
        <p class="text-white text-box-wrapper">Nous utilisons des protocoles de sécurité avancés pour protéger vos informations.</p>

        <p class="fw-bold text-white title-box-wrapper">Divulgation des Données</p>
        <p class="text-white text-box-wrapper">Nous pouvons être amenés à divulguer certaines informations en cas d’obligation légale.</p>

        <p class="fw-bold text-white title-box-wrapper">Prestataires de Services</p>
        <p class="text-white text-box-wrapper">Nous faisons appel à des prestataires externes pour l’hébergement et la gestion du site.</p>

        <p class="fw-bold text-white title-box-wrapper">Liens vers d'autres Sites</p>
        <p class="text-white text-box-wrapper">Nous ne sommes pas responsables des pratiques de confidentialité des sites tiers.</p>

        <p class="fw-bold text-white title-box-wrapper">Confidentialité des Enfants</p>
        <p class="text-white text-box-wrapper">Notre site est interdit aux mineurs et nous ne collectons pas sciemment leurs données.</p>

        <p class="fw-bold text-white title-box-wrapper">Modifications de cette Politique de Confidentialité</p>
        <p class="text-white text-box-wrapper">Nous nous réservons le droit de modifier cette politique et informerons les utilisateurs des mises à jour.</p>

        <p class="fw-bold text-white title-box-wrapper">Contactez-nous</p>
        <p class="text-white text-box-wrapper">Pour toute question sur la confidentialité, contactez-nous à contact@placetonbet.fr.</p>
    </div>
</section>