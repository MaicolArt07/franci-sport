<section class="section section-subscribe mt-4 mb-4">
    <div class="row justify-content-center align-items-center">
        <div class="col-md-12">
            <h1 class="text-white title-form-contact">Contactez-nous</h1>
            <?php echo do_shortcode('[contact-form-7 id="5aa1951" html_class="contact-form"]'); ?>
        </div>
    </div>  
</section>